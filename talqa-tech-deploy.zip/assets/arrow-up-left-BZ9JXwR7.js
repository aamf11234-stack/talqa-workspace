import{c as o}from"./index-D8NsszyD.js";const e=[["path",{d:"M7 17V7h10",key:"11bw93"}],["path",{d:"M17 17 7 7",key:"2786uv"}]],r=o("arrow-up-left",e);export{r as A};
